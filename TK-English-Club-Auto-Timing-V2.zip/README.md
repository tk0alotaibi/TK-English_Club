# TK English Club — Automatic Timing Version

This version accepts an MP3 and its TXT transcript, uploads the MP3 temporarily, asks OpenAI Whisper for word timestamps, aligns those words to the supplied transcript sentences, and highlights the current sentence during playback.

## Required Vercel setup

1. Create a **Vercel Blob** store and connect it to this project. Vercel automatically adds `BLOB_READ_WRITE_TOKEN`.
2. Add an Environment Variable named `OPENAI_API_KEY` containing an OpenAI API key.
3. Redeploy the project.

## Upload to GitHub

Upload the contents of this folder to the repository root. It is fine to leave the old static files, but this project must include:

- `app/`
- `lib/`
- `package.json`
- `next.config.mjs`

Vercel should detect **Next.js** automatically after the commit.

## Limits

- MP3 only
- Maximum MP3 size: 25 MB
- English audio/transcript
- The temporary Blob upload is deleted after timing generation

## How it works

1. Browser uploads the MP3 directly to Vercel Blob, avoiding the Vercel Function request-body limit.
2. The server downloads the temporary file and sends it to OpenAI `whisper-1` using word timestamps.
3. The server aligns the supplied transcript sentences to Whisper's timestamped words.
4. The temporary MP3 in Blob is deleted.
5. The browser plays the user's local MP3 and uses the returned sentence timing JSON for highlighting.
