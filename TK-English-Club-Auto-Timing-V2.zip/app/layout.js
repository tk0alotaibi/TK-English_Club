import './globals.css';

export const metadata = {
  title: 'TK English Club',
  description: 'Private MP3 lesson player with automatic transcript timing.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
