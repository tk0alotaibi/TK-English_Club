import { del } from '@vercel/blob';
import OpenAI from 'openai';
import { alignTranscript } from '../../../lib/align';

export const runtime = 'nodejs';
export const maxDuration = 300;

export async function POST(request) {
  let blobUrl = '';

  try {
    const body = await request.json();
    blobUrl = String(body.blobUrl || '');
    const transcript = String(body.transcript || '').trim();
    const filename = String(body.filename || 'lesson.mp3');

    if (!process.env.OPENAI_API_KEY) {
      return Response.json({ error: 'OPENAI_API_KEY is not configured in Vercel.' }, { status: 500 });
    }
    if (!blobUrl || !transcript) {
      return Response.json({ error: 'Audio and transcript are required.' }, { status: 400 });
    }

    const audioResponse = await fetch(blobUrl);
    if (!audioResponse.ok) throw new Error('The temporary MP3 could not be downloaded.');
    const audioBuffer = await audioResponse.arrayBuffer();

    if (audioBuffer.byteLength > 25 * 1024 * 1024) {
      throw new Error('The MP3 must be smaller than 25 MB.');
    }

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const audioFile = new File([audioBuffer], filename, { type: 'audio/mpeg' });

    const result = await openai.audio.transcriptions.create({
      file: audioFile,
      model: 'whisper-1',
      language: 'en',
      response_format: 'verbose_json',
      timestamp_granularities: ['word'],
      prompt: transcript.slice(0, 1200),
      temperature: 0,
    });

    const timedSentences = alignTranscript(transcript, result.words || []);
    const averageConfidence = timedSentences.reduce((sum, item) => sum + item.confidence, 0) / timedSentences.length;

    return Response.json({
      title: filename.replace(/\.mp3$/i, ''),
      language: result.language || 'en',
      duration: result.duration || timedSentences.at(-1)?.end || 0,
      recognizedText: result.text || '',
      sentences: timedSentences,
      quality: averageConfidence >= 0.78 ? 'high' : averageConfidence >= 0.58 ? 'medium' : 'review',
      averageConfidence: Number(averageConfidence.toFixed(3)),
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : 'Automatic timing failed.' },
      { status: 500 },
    );
  } finally {
    if (blobUrl) {
      try { await del(blobUrl); } catch {}
    }
  }
}
