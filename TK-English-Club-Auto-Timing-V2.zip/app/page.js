'use client';

import { upload } from '@vercel/blob/client';
import { useEffect, useMemo, useRef, useState } from 'react';

const ACCEPTED = ['audio/mpeg', 'audio/mp3'];

function formatTime(seconds = 0) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
}

export default function Home() {
  const audioRef = useRef(null);
  const activeRef = useRef(null);
  const [audioFile, setAudioFile] = useState(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [transcript, setTranscript] = useState('');
  const [timing, setTiming] = useState(null);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [search, setSearch] = useState('');
  const [speed, setSpeed] = useState(1);
  const [status, setStatus] = useState('Choose an MP3 and transcript.');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => () => { if (audioUrl) URL.revokeObjectURL(audioUrl); }, [audioUrl]);

  useEffect(() => {
    if (activeRef.current) activeRef.current.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }, [activeIndex]);

  const searchLower = search.trim().toLowerCase();
  const sentences = timing?.sentences || [];
  const progress = sentences.length ? Math.max(0, ((activeIndex + 1) / sentences.length) * 100) : 0;

  function selectAudio(file) {
    setError('');
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.mp3') || (file.type && !ACCEPTED.includes(file.type))) {
      setError('Choose an MP3 file only.');
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      setError('The MP3 must be smaller than 25 MB.');
      return;
    }
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioFile(file);
    setAudioUrl(URL.createObjectURL(file));
    setTiming(null);
    setActiveIndex(-1);
    setStatus('MP3 ready. Add the transcript, then generate timing.');
  }

  async function selectText(file) {
    if (!file) return;
    const text = await file.text();
    setTranscript(text);
    setTiming(null);
  }

  async function generateTiming() {
    setError('');
    if (!audioFile) return setError('Choose an MP3 first.');
    if (!transcript.trim()) return setError('Choose or paste the transcript.');

    setBusy(true);
    try {
      setStatus('Uploading the MP3 securely…');
      const blob = await upload(`temporary/${audioFile.name}`, audioFile, {
        access: 'public',
        handleUploadUrl: '/api/upload',
        multipart: true,
      });

      setStatus('Listening and generating exact word timestamps…');
      const response = await fetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ blobUrl: blob.url, transcript, filename: audioFile.name }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Timing generation failed.');

      setTiming(data);
      setActiveIndex(0);
      setStatus(`Timing ready — ${data.sentences.length} sentences (${data.quality} match).`);
      localStorage.setItem('tk-last-timing', JSON.stringify(data));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Timing generation failed.');
      setStatus('Could not generate timing.');
    } finally {
      setBusy(false);
    }
  }

  function onTimeUpdate() {
    if (!timing || !audioRef.current) return;
    const current = audioRef.current.currentTime;
    let low = 0;
    let high = timing.sentences.length - 1;
    let found = -1;
    while (low <= high) {
      const mid = Math.floor((low + high) / 2);
      const item = timing.sentences[mid];
      if (current < item.start) high = mid - 1;
      else if (current > item.end) low = mid + 1;
      else { found = mid; break; }
    }
    if (found === -1) found = Math.max(0, Math.min(timing.sentences.length - 1, high));
    if (found !== activeIndex) setActiveIndex(found);
  }

  function jumpTo(index) {
    const item = sentences[index];
    if (!item || !audioRef.current) return;
    audioRef.current.currentTime = item.start;
    setActiveIndex(index);
    audioRef.current.play().catch(() => {});
  }

  function downloadTiming() {
    if (!timing) return;
    const file = new Blob([JSON.stringify(timing, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(file);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${timing.title || 'lesson'}-timing.json`;
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main>
      <header className="header">
        <div>
          <span className="kicker">PRIVATE STUDY PLAYER</span>
          <h1>TK English Club</h1>
        </div>
        <div className="headerBadge">MP3 + TXT → Auto timing</div>
      </header>

      <section className="grid">
        <aside className="panel setup">
          <div className="step"><b>1</b><span>Choose the original MP3</span></div>
          <label className="fileButton">
            <input type="file" accept=".mp3,audio/mpeg" onChange={(e) => selectAudio(e.target.files?.[0])} />
            <strong>🎧 MP3 file</strong>
            <small>{audioFile?.name || 'Tap to choose MP3'}</small>
          </label>

          <div className="step"><b>2</b><span>Add the matching transcript</span></div>
          <label className="fileButton">
            <input type="file" accept=".txt,text/plain" onChange={(e) => selectText(e.target.files?.[0])} />
            <strong>📄 Transcript file</strong>
            <small>Choose TXT</small>
          </label>
          <textarea value={transcript} onChange={(e) => setTranscript(e.target.value)} placeholder="Or paste the lesson transcript here…" rows={10} />

          <button className="primary" disabled={busy} onClick={generateTiming}>
            {busy ? 'Working…' : 'Generate automatic timing'}
          </button>
          <p className="status">{status}</p>
          {error && <p className="error">{error}</p>}
          <p className="privacy">The temporary uploaded MP3 is deleted after timing is generated.</p>
        </aside>

        <section className="panel player">
          <div className="playerTop">
            <div>
              <span className="kicker">NOW STUDYING</span>
              <h2>{timing?.title || audioFile?.name?.replace(/\.mp3$/i, '') || 'No lesson loaded'}</h2>
            </div>
            <span className="counter">{activeIndex + 1 > 0 ? activeIndex + 1 : 0} / {sentences.length}</span>
          </div>

          <audio ref={audioRef} src={audioUrl} controls onTimeUpdate={onTimeUpdate} onLoadedMetadata={() => { if (audioRef.current) audioRef.current.playbackRate = speed; }} />
          <div className="progress"><span style={{ width: `${progress}%` }} /></div>

          <div className="toolbar">
            <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search transcript" />
            <select value={speed} onChange={(e) => { const value = Number(e.target.value); setSpeed(value); if (audioRef.current) audioRef.current.playbackRate = value; }}>
              {[0.75, 0.9, 1, 1.1, 1.25, 1.5, 2].map((item) => <option key={item} value={item}>{item.toFixed(2)}×</option>)}
            </select>
            {timing && <button className="secondary" onClick={downloadTiming}>Save timing</button>}
          </div>

          <article className="transcript">
            {!sentences.length ? (
              <div className="empty"><span>🎙️</span><h3>Your timed transcript will appear here</h3><p>Choose MP3 + TXT, then press Generate automatic timing.</p></div>
            ) : sentences.map((item, index) => {
              const match = searchLower && item.text.toLowerCase().includes(searchLower);
              return (
                <button
                  type="button"
                  key={`${item.id}-${index}`}
                  ref={index === activeIndex ? activeRef : null}
                  className={`sentence ${index === activeIndex ? 'active' : ''} ${match ? 'match' : ''}`}
                  onClick={() => jumpTo(index)}
                >
                  <span className="time">{formatTime(item.start)}</span>
                  <span>{item.text}</span>
                </button>
              );
            })}
          </article>
        </section>
      </section>
    </main>
  );
}
