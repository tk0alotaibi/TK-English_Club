# TK English Club V2

Automatic MP3 timing with OpenAI Whisper and Vercel Blob.

Required Vercel variables:
- OPENAI_API_KEY
- BLOB_READ_WRITE_TOKEN (created automatically after connecting a Blob store)

MP3 limit: 25 MB.
