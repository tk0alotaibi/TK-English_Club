import type { TimedSentence } from "@/types";

type WordStamp = { word: string; start: number; end: number };

function normalizeWord(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9']/g, "");
}

export function splitSentences(text: string): string[] {
  const normalized = text
    .replace(/\r/g, "")
    .replace(/\n+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  const matches = normalized.match(/[^.!?…]+(?:[.!?…]+["'’”)]*|$)/g);
  return (matches ?? [normalized]).map((item) => item.trim()).filter(Boolean);
}

export function align(text: string, words: WordStamp[]): TimedSentence[] {
  const sentences = splitSentences(text);
  const cleanWords = words
    .map((item) => ({ ...item, normalized: normalizeWord(item.word) }))
    .filter((item) => item.normalized);

  let cursor = 0;

  return sentences.map((sentence, sentenceIndex) => {
    const tokens = (sentence.match(/[A-Za-z0-9]+(?:['’][A-Za-z0-9]+)*/g) ?? [])
      .map(normalizeWord)
      .filter(Boolean);

    if (!tokens.length || !cleanWords.length) {
      const start = sentenceIndex * 2;
      return { id: crypto.randomUUID(), text: sentence, start, end: start + 2 };
    }

    let bestStart = cursor;
    let bestScore = -1;
    const searchEnd = Math.min(cleanWords.length, cursor + Math.max(80, tokens.length * 5));

    for (let candidate = cursor; candidate < searchEnd; candidate++) {
      let score = 0;
      let wordIndex = 0;
      const window = cleanWords.slice(candidate, candidate + tokens.length + 12);

      for (const token of tokens) {
        while (wordIndex < window.length && window[wordIndex].normalized !== token) {
          wordIndex += 1;
        }
        if (wordIndex < window.length) {
          score += 1;
          wordIndex += 1;
        }
      }

      if (score > bestScore) {
        bestScore = score;
        bestStart = candidate;
      }
      if (score >= Math.ceil(tokens.length * 0.9)) break;
    }

    let matched = 0;
    let endIndex = bestStart;
    for (let index = bestStart; index < cleanWords.length && matched < tokens.length; index++) {
      if (cleanWords[index].normalized === tokens[matched]) {
        matched += 1;
        endIndex = index;
      }
      if (index - bestStart > tokens.length * 5 + 25) break;
    }

    if (matched < Math.max(1, Math.floor(tokens.length * 0.3))) {
      endIndex = Math.min(cleanWords.length - 1, bestStart + Math.max(0, tokens.length - 1));
    }

    cursor = Math.min(cleanWords.length, endIndex + 1);
    const start = cleanWords[bestStart]?.start ?? 0;
    const finish = cleanWords[endIndex]?.end ?? start + 2;

    return {
      id: crypto.randomUUID(),
      text: sentence,
      start,
      end: Math.max(finish, start + 0.15),
    };
  });
}
