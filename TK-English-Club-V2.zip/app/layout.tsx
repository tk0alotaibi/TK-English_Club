import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TK English Club V2",
  description: "Automatic MP3 transcript timing and highlighting"
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
