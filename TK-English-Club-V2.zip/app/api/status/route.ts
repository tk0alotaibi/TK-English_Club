import {NextResponse} from "next/server";
export function GET(){return NextResponse.json({openai:Boolean(process.env.OPENAI_API_KEY),blob:Boolean(process.env.BLOB_READ_WRITE_TOKEN)})}
