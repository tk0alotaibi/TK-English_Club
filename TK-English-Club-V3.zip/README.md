# TK English Club — Version 3

## New in V3

- Visible OpenAI and MP3-storage readiness check
- Clear warning when Vercel Blob is not connected
- Export generated sentence timing as JSON
- All V2 automatic timing, highlighting, dictionary, library, search, speed, and saved-position features

## Required Vercel settings

1. `OPENAI_API_KEY` in Environment Variables.
2. Connect a **Public Vercel Blob** store to the project. Vercel adds `BLOB_READ_WRITE_TOKEN`.

## Deploy in Codespaces

```bash
unzip -o TK-English-Club-V3.zip
npm install
npm run build
git add .
git commit -m "Deploy TK English Club V3"
git pull origin main --rebase
git push origin main
```
